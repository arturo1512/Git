# Hyperblog 💚
Un blog increíble para el[ curso de Git y Github](https://platzi.com/cursos/git-github/ " curso de Git y Github") de [Platzi](https://platzi.com/ "Platzi")
> El curso de Git y Github de Platzi es lo que me hacía falta para triplicar mi salario y lanzarme a la industria del tejido de lana sintética con Machine Learning
> - niñita

## En este curso vemos de todo
* Todos los comandos de Git
* El flujo de trabajo en Github
* El verdadero amor por las buenas prácticas
* Trucos muy locos del profesor
* Las personalidades múltiples de Freddy
* Creado por el increíble Platzi Team
* Incluye ejemplos en Windows, Linux y Mac
* Disponible para todas las edades

Y como un amable recordatorio: **Este readme.md es un chiste**.  Diseñado para el ejemplo. Si llegas acá NO TE LO TOMES EN SERIO y mejor ve [**a ver el curso**](https://platzi.com/cursos/git-github/ "a ver el curso").